#!/bin/bash

find ~/bikenwgrowth/data/ -type f -name '*_edges.csv' -delete
find ~/bikenwgrowth/data/ -type f -name '*_nodes.csv' -delete