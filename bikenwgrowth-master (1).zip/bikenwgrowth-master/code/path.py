PATH = {}
PATH["parameters"] = "../parameters/"
PATH["data"] = "../../bikenwgrowth_external/data/"
PATH["plots"] = "../../bikenwgrowth_external/plots/"
PATH["plots_networks"] = "../../bikenwgrowth_external/plotsnetworks/"
PATH["results"] = "../../bikenwgrowth_external/results/"
PATH["results_constricted"] = "../../bikenwgrowth_external/results_constricted/"
PATH["videos"] = "../../bikenwgrowth_external/videos/"
PATH["exports"] = "../../bikenwgrowth_external/exports/"
PATH["exports_json"] = "../../bikenwgrowth_external/exports_json/"
PATH["logs"] = "../../bikenwgrowth_external/logs/"

print("Loaded PATH.\n")